package toys;

/**
 * file: IToy.java
 * This interface is for running the behaviors of the Toy class
 * Used by Junit tests and the main program
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public interface IToy {

    /**
     * Getting product code of a specific product
     * @return product code
     */
    int getProductCode();
    /**
     * Getting name of a specific product
     * @return name
     */
    String getName();
    /**
     * Getting happiness of a specific product
     * @return happiness
     */
    int getHappiness();

    /**
     * Testing a product to see if its retired
     * @return toy status of usage
     */
    boolean isRetired();
    /**
     * Getting wear of a product
     * @return wear of a specific product
     */
    double getWear();
    /**
     * Increase wear of a specific product by a specific amount
     * @param amount: amount to increase wear by
     */
    void increaseWear(double amount);
    /**
     * Play Method for the Toy Class
     * @param time: amount of time product is played with
     */
    void play(int time);
}
