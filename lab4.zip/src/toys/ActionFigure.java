package toys;

/**
 * Class for making an action figure
 * file: ActionFigure.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class ActionFigure extends Doll{
    //Initial Energy Level
    public final static int MIN_ENERGY_LEVEL = 1;
    //Hair Color of ActionFigure
    public final static Color HAIR_COLOR = Color.ORANGE;
    //How old the toy is
    private final int age;
    //Catchphrase of the toy
    private final String speak;
    //Energy level of the toy
    private int energyLevel;

    /**
     * Initialization of the Action Figure
     * @param name: Name of the toy
     * @param age: Age of the toy
     * @param speak: Catchphrase of the toy
     */
    protected ActionFigure(String name, int age, String speak){
        super(name, HAIR_COLOR, age, speak);
        this.age = age;
        this.speak = speak;
        this.energyLevel = MIN_ENERGY_LEVEL;

    }

    /**
     * Getting energy level of Action Figure
     * @return energy level of Action Figure
     */
    public int getEnergyLevel(){
        return this.energyLevel;
    }

    /**
     * Getting age of Action Figure
     * @return age of Action Figure
     */
    public int getAge(){
        return this.age;
    }

    /**
     * Getting catchphrase of action figure
     * @return catchphrase of action figure
     */
    public String getSpeak(){
        return this.speak;
    }

    /**
     * Play method specifically for Action Figure
     * Energy Level increases by one
     * @param time: time Action Figure is played with
     */
    @Override
    protected void specialPlay(int time) {
        System.out.println("\t" + super.getName() + " kung foo chops with " + energyLevel*time +
                " energy!");
        this.energyLevel++;
        super.specialPlay(time);
    }

    /**
     * Printing out an Action Figure
     * @return representation of Action Figure
     */
    @Override
    public String toString(){
        return super.toString() + ", ActionFigure{E:" + getEnergyLevel()+ "}";
    }
}

