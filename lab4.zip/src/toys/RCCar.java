package toys;

/**
 * Class for making race car
 * file: RCCar.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class RCCar extends BatteryPowered{
    //Initial Speed of a race car
    public final static int STARTING_SPEED = 10;
    //Increase of speed for the race car
    public final static int SPEED_INCREASE = 5;
    //Initial product code of the race car
    private static int productCode = 300;
    //Speed of the race car
    private int speed;

    /**
     * Initialization of the race car
     * @param name: name of the race car
     * @param numBatteries: number of batteries
     */
    protected RCCar(String name, int numBatteries){
        super(name, productCode++, numBatteries);
        this.speed = STARTING_SPEED;
    }

    /**
     * Getting speed of the race car
     * @return speed of the race car
     */
    public int getSpeed(){
        return this.speed;
    }

    /**
     * PLay method for the race car
     * Battery level decreases
     * Speed increases by 5
     * Increases wear by speed
     * @param time: time race car is played with
     */
    @Override
    public void specialPlay(int time){
        System.out.println("\t" + getName() + " races around at " + getSpeed() +
                "mph!");
        super.useBatteries(time);
        super.increaseWear(getSpeed());
        this.speed = getSpeed() + SPEED_INCREASE;
    }

    /**
     * Printing out a race car
     * @return representation of a race car
     */
    @Override
    public String toString(){
        return super.toString() + ", RCCar{S:" + getSpeed() + "}";
    }
}
