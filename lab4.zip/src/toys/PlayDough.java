package toys;
/**
 * Class for making a PlayDough
 * file: PlayDough.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class PlayDough extends Toy{
    //How much the play dough gets worn out by
    public final static double WEAR_MULTIPLIER = .05;
    //color of the play dough
    private final Color color;
    //product code of the play dough
    private static int productCode = 100;

    /**
     * Initialization of the play dough toy
     * @param name: name of the play dough
     */
    protected PlayDough(String name, Color color){
        super(name, productCode++);
        this.color = color;
    }

    /**
     * Getting color of the play dough
     * @return color of the play dough
     */
    public Color getColor(){
        return this.color;
    }

    /**
     * Play method specifically for play dough
     * @param time: time play dough is played with
     */
    @Override
    protected void specialPlay(int time) {
        System.out.println("\tArts and crafting with " + this.color + " " + getName());
        increaseWear(time*WEAR_MULTIPLIER);
    }

    /**
     * Printing out Play Dough
     * @return representation of Play dough
     */
    @Override
    public String toString(){
        return super.toString() + ", " +  "PlayDough{C:" + getColor() + "}";
    }
}
