package toys;

/**
 * Class for making a Doll
 * file: Doll.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class Doll extends Toy{
    //Hair Color of DOll
    private final Color hairColor;
    //How old the toy is
    private final int age;
    //Catchphrase of the toy
    private final String speak;
    //Initial product code of a doll
    private static int productCode = 200;

    /**
     * Initialization of the DOll
     * @param name: Name of the doll
     * @param hairColor: Hair Color of the Doll
     * @param age; Age of the doll
     * @param speak: Catchphrase of the doll
     */
    protected Doll(String name, Color hairColor, int age, String speak){
        super(name, productCode++);
        this.hairColor = hairColor;
        this.age = age;
        this.speak = speak;
    }

    /**
     * Getting hair color of the doll
     * @return hair color of the doll
     */
    public Color getHairColor(){
        return this.hairColor;
    }

    /**
     * Getting hair color of the doll
     * @return hair color of the doll
     */
    public int getAge(){
        return this.age;
    }

    /**
     * Getting catchphrase of the doll
     * @return catchphrase of the doll
     */
    public String getSpeak(){
        return this.speak;
    }

    /**
     * Play method specifically for Doll
     * Increases wear by age
     * @param time: time doll is played with
     */
    @Override
    protected void specialPlay(int time) {
        System.out.println("\t" + super.getName() + " brushes their " + getHairColor() +
                " hair and says, " + "\"" + getSpeak() + "\"");
        super.increaseWear(getAge());
    }
    /**
     * Printing out a Doll
     * @return Representation of Doll
     */
    @Override
    public String toString(){
        return super.toString() + ", " +  "Doll{HC:" + getHairColor() +
                ", A:" +getAge() + ", S:" + getSpeak() + "}";
    }
}

