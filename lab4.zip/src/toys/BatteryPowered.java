package toys;

/**
 * Class for making a Battery Powered Toy
 * file: BatteryPowered.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public abstract class BatteryPowered extends Toy{
    //Max Battery Level
    public final static int FULLY_CHARGED = 100;
    //Depleted Battery Level
    public final static int DEPLETED = 0;
    //NUmber of batteries in battery powered toy
    private final int numBatteries;
    //How much battery level is in the toy
    private int batteryLevel;
    /**
     * Initializing product code and name
     *
     * @param name        : name of a toy
     * @param productCode : code number of a toy
     */
    protected BatteryPowered(String name, int productCode, int numBatteries) {
        super(name, productCode);
        this.numBatteries = numBatteries;
        this.batteryLevel = FULLY_CHARGED;
    }

    /**
     * Getting battery level
     * @return battery level
     */
    public int getBatteryLevel(){
        return this.batteryLevel;
    }

    /**
     * Getting number of batteries
     * @return number of batteries
     */
    public int getNumBatteries(){
        return this.numBatteries;
    }

    /**
     * Method about usage of batteries
     * Print out statements about depletion and recharge
     * @param time: time used for decreasing battery level
     */
    public void useBatteries(int time){
        this.batteryLevel -= (time + getNumBatteries());
        if (getBatteryLevel() <= DEPLETED){
            this.batteryLevel = DEPLETED;
            System.out.println("\tDEPLETED:" + this);
            this.batteryLevel = FULLY_CHARGED;
            System.out.println("\tRECHARGED:" + this);
        }
    }

    /**
     * Printing out Battery Powered
     * @return Representation of Battery Powered Toy
     */
    @Override
    public String toString(){
        return super.toString() + ", " +  "BatteryPowered{BL:" + getBatteryLevel() + ", NB:" + getNumBatteries() + "}";
    }
}
