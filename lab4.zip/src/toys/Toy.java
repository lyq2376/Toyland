package toys;

/**
 * Abstract superclass for the foundation of toys
 * file: Toy.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public abstract class Toy implements IToy{
    //Initial happiness of toy
    public final static int INITIAL_HAPPINESS = 0;
    //Max happiness of toy
    public final static int MAX_HAPPINESS = 100;
    //Initial status of toy
    public final static double INITIAL_WEAR = 0.0;
    //happiness of toy
    private int happiness;
    // status of toy
    private double wear;
    // product code of toy
    private final int productCode;
    //name of toy
    private final String name;

    /**
     * Initializing product code and name
     *
     * @param productCode: code number of a toy
     * @param name: name of a toy
     */
    protected Toy(String name, int productCode) {
        this.productCode = productCode;
        this.name = name;
        this.happiness = INITIAL_HAPPINESS;
        this.wear = INITIAL_WEAR;
    }

    /**
     * Getting product code of a specific product
     * @return product code
     */
    @Override
    public int getProductCode(){
        return this.productCode;
    }

    /**
     * Getting name of a specific product
     * @return name
     */
    @Override
    public String getName(){
        return this.name;
    }

    /**
     * Getting happiness of a specific product
     * @return happiness
     */
    @Override
    public int getHappiness(){
        return this.happiness;
    }

    /**
     * Testing a product to see if its retired
     * @return toy status of usage
     */
    @Override
    public boolean isRetired(){
        return getHappiness() >= MAX_HAPPINESS;
    }

    /**
     * Getting wear of a product
     * @return wear of a specific product
     */
    @Override
    public double getWear(){
        return this.wear;
    }

    /**
     * Increase wear of a specific product by a specific amount
     * @param amount: amount to increase wear by
     */
    @Override
    public void increaseWear(double amount){
        this.wear = getWear() + amount;
    }

    /**
     * Base Play method
     * @param time: amount of time product is played with
     */
    @Override
    public void play(int time){
        System.out.println("PLAYING(" + time + "): " + this);
        specialPlay(time);
        this.happiness = getHappiness()+time;
        if(isRetired()){
            System.out.println("RETIRED: " + this);
        }
    }

    /**
     * An abstract method due to toys having different functions
     * @param time: time toy is played with
     */

    protected abstract void specialPlay(int time);

    /**
     * Printing out a Toy
     * @return Representation of Toy
     */
    @Override
        public String toString(){
        return "Toy{PC:" + getProductCode() + ", N:" + getName() + ", H:" + getHappiness() +", R:" + isRetired()+ ", W:" + getWear() + "}";
    }

}
