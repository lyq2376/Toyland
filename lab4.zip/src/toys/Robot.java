package toys;
/**
 * Class for making a robot
 * file: Robot.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class Robot extends BatteryPowered{
    //Fly Speed of the robot
    public final static int FLY_SPEED = 25;
    //RUn Speed of the robot
    public final static int RUN_SPEED = 10;
    //Initial speed of the robot
    public final static int INITIAL_SPEED = 0;
    //Initial product code of the robot
    private static int productCode = 400;
    //If the robot is flying
    private final boolean fly;
    //Distance robot is traveling
    private int distance;

    /**
     * Initialization of the Robot
     * @param name: name of the robot
     * @param numBatteries: number of batteries
     * @param fly: status of fly or not
     */
    protected Robot(String name, int numBatteries, boolean fly){
        super(name, productCode++, numBatteries);
        this.fly = fly;
        this.distance = INITIAL_SPEED;
    }

    /**
     * Getting travel status of robot
     * @return if the robot is flying or not
     */
    public boolean isFlying(){
        return this.fly;
    }

    /**
     * Getting distance robot is moving
     * @return how much the robot has traveled
     */
    public int getDistance(){
        return this.distance;
    }

    /**
     * Play Method of the Robot
     * Prints out statements for flying and running robot
     * Increases wear by either fly speed or running speed
     * Batteries are used up
     * @param time: time robot is played with
     */
    @Override
    protected void specialPlay(int time) {
        if(isFlying()) {
            this.distance = getDistance()+(time*FLY_SPEED);
            System.out.println("\t" + super.getName() + " is flying around with total distance: " + getDistance());
            super.increaseWear(FLY_SPEED);
            super.useBatteries(time);
        }
        else{
            this.distance = getDistance()+(time*RUN_SPEED);
            System.out.println("\t" + super.getName() + " is running around with total distance: " + getDistance());
            super.increaseWear(RUN_SPEED);
            super.useBatteries(time);
        }
    }

    /**
     * Printing out a robot
     * @return representation of a robot
     */
    @Override
    public String toString(){
        return super.toString() + ", Robot{F:" + isFlying() + ", D:" + getDistance() +"}";
    }
}
